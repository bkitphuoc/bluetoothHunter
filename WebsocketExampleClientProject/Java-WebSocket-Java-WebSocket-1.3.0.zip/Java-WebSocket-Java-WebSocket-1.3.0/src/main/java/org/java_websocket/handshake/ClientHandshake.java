package org.java_websocket.handshake;

public interface ClientHandshake extends Handshakedata {
	public String getResourceDescriptor();
}
